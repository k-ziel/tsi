// Skrypt startowy
